This module is tested and works properly with dolibarr default theme.

Allow entry of VAT inclusive/exclusive prices on :
   * Customer quotations
   * Customer orders
   * Customer invoices
   * Contracts
   * Supplier invoices
   * Supplier orders
   
   
=========================================================================
Ce module a été testé et fonctionne correctement avec le thème par défaut de
Dolibarr.

Permet la saisie des prix TTC ou HT sur :
   * Propositions client
   * Commandes client
   * Factures client
   * Contrats
   * Factures fournisseur
   * Commandes fournisseur
   
========================================================================
Assistance / Support : sami.fetaimia@gmail.com