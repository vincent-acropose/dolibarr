/*
 * Config
 */
var cfg = require('./config');

/*
 * Depend
 */
var _mysql = require('mysql');





var mysql = _mysql.createConnection({
	host: cfg.HOST,
	port: cfg.PORT,
	user: cfg.MYSQL_USER,
	password: cfg.MYSQL_PASS,
});


mysql.query('use ' + cfg.DATABASE );




function query( query ){

	 mysql.query( query  ,
							function(err, result, fields) {
								if (err)
									throw err;
								else {
									if(cfg.debug)
										console.log('[sql]' + query);

									exports.result = result;
								}
							}
				);

}

/*
 * Export function
 */
exports.query = query;
