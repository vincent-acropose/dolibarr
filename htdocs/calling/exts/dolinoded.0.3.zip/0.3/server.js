/*
 * Config
 */
var cfg = require('./config');
/*
 * Depend
 */
var http = require('http'),
			socket = require('socket.io');






function start(port) {

	function handler(request, response)
	{
		response.write(page);
		response.end();
	}

	var app = http.createServer(function(r, s){ handler(r,s); });
	app.listen( port );

	var listener = socket.listen(app, {
		log: false,
		flashPolicyServer: false,
		transports: [
		'websocket',
		'jsonp-polling'
		]
	});

	if(cfg.debug)
		console.log('[server] start ');

	return listener;

}


/*
 * Export function
 */
exports.start = start;

/*
 * Export data
 */
exports.socket = socket;

