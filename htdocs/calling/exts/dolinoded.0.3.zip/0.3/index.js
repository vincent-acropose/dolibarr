/*
 * Config
 */
var cfg = require('./config');
/*
 * Depend
 */
var server = require('./server');
var sql = require('./mysql');

/*
 * Start Http serveur
 */
listener = server.start(cfg.port);



function InitCalling(userid , alert_type ){

	if(cfg.debug)
		console.log("[index] loop user : " + userid);

	var _query = 'SELECT rowid , data FROM ' + cfg.MAIN_DB_PREFIX + 'calling  WHERE  mode IN (1,2) ' ;

	if(alert_type == 1)
		_query += ' AND ( call_to_user_id = ' + userid + ' OR call_to_user_id = 0 )' ;

	_query += ' LIMIT 1' ;

	sql.query(_query);
	var result = sql.result;

	if(result){

		var detail = result[0];

		if(detail){

			if(cfg.debug)
				console.log("[index] loop call user : " + userid + " and rowid " + detail.rowid);


				var obj = JSON.parse(detail.data);

				if(cfg.debug)
					console.log( obj );

					listener.sockets.emit(
						'notification',
						JSON.stringify({
							"foruser": userid ,
							"message":  '1',
							"collaborateur": obj.collaborateur,
							"user": obj.user

						})
					);
		}
		else
			listener.sockets.emit('notification', JSON.stringify({  "foruser": userid , "message":  '0'})  );
	}
}




/*
 * result interval
 */
var session = new Array;
/*
 * result interval
 */
var itinter = new Array;

// main
listener.sockets.on('connection', function (socket) {
	if(cfg.debug)
		console.log('[index] connection');


	/*
	 * Alert type mode ( 0, 1, 2, 3,)
	 */
	var alert_type = 0;



	socket.on('foruser', function(data) {

		if(cfg.debug)
			console.log( session );

		if(data.userid > 0) {
			if( session.indexOf(data.userid) == -1) {
				session[data.userid] = data.userid;

				if(cfg.debug)
					console.log('[index] user connected id : ' + data.userid);

				itinter[data.userid] = setInterval(function(){InitCalling(data.userid, data.calling_alert_type ); },1500);
			}
			else	if(cfg.debug)
				console.log('[index] user prev loggued id : ' + data.userid);
		}
	});



		/**
		* Disconnect user and clear interval
		*/
	socket.on('logoff', function(data) {

		if(cfg.debug)
			console.log('[index] user disconnect id : ' + data.userid);

		if(data.userid> 0) {
			clearInterval( itinter[data.userid] );
			delete  itinter.splice( data.userid,1);
			delete  session.splice( data.userid,1);
			delete  userid ;
		}
	});

} );



