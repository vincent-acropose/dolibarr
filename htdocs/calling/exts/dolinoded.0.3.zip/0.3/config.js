/*
 * debug
 */
var debug = false;
exports.debug = debug;
/*
 * Port du server http
 */
var port = 1337;
exports.port = port;
/*
 * Config mysql
 */
var HOST = 'localhost';
exports.HOST = HOST;
var PORT = 3306;
exports.PORT = PORT;
var MYSQL_USER = 'doli';
exports.MYSQL_USER = MYSQL_USER;
var MYSQL_PASS = '3541331';
exports.MYSQL_PASS = MYSQL_PASS;
var DATABASE = 'doliarr';
exports.DATABASE = DATABASE;
var MAIN_DB_PREFIX = 'llx_';
exports.MAIN_DB_PREFIX = MAIN_DB_PREFIX;